# semana_7_actividad_3_flutter

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.


A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

Está aplicación en la página principal tiene un contador y 2 botones para navegar a las pantallas A y B,
donde estás muestran el valor del contador recibido y un boton para incrementar el contador. 
La actualización del contador en las pantallas se logra con el método setState, la navegación de las
pantallas Navigator y MaterialPageRoute.

